#include <thread>
#include "EasyTcpClient.hpp"

void cmd_process(EasyTcpClient* client){
	while(1){
		char buff[BUFSIZ] = {};
		scanf("%s", buff);
		if(0==strcmp(buff, "exit")){
			printf("退出线程\n");
			client->Close();
			break;
		}else if(0 == strcmp(buff, "login")){
			Login login;
			strcpy(login.username, "wu");
			strcpy(login.password, "wupassword");
			client->sendData(&login);
		}else if(0 == strcmp(buff, "logout")){
			Logout logout;
			strcpy(logout.username, "wu");
			client->sendData(&logout);
		}else
		{
			printf("输入有误，重新输入\n");
		}		
	}
}


int main(){
	EasyTcpClient client;
	client.initSocket();
	client.Connect("127.0.0.1", 6666);

//启动线程
	std::thread t1(cmd_process, &client);
	t1.detach();

	EasyTcpClient client2;
	client2.initSocket();
	client2.Connect("127.0.0.1", 6668);
	
//启动线程
	std::thread t2(cmd_process, &client2);
	t2.detach();

	char buff[BUFSIZ];
	while(client.isRun() || client2.isRun())
	{
		client2.OnRun();
		client.OnRun();
	}
	client.Close();
	client2.Close();
	printf("exit\n");
	return 0;
}
