#ifndef _EasyTcpClient_hpp_
#define _EasyTcpClient_hpp_

#ifdef _WIN32
    #define WIN32_LEAN_AND_MEAN
    #include<windows.h>
    #include<WinSock2.h>
    #pragma comment(lib, "ws2_32.lib")
#else
    #include<string.h>
    #include<unistd.h>
    #include<arpa/inet.h>

    #define SOCKET int
    #define INVALID_SOCKET (SOCKET)(~0)
    #define SOCKET_ERROR           (-1)
#endif

#include<stdio.h>
#include<thread>
#include "MessageHeader.hpp"

class EasyTcpClient
{
private:
    SOCKET _cfd;
public:
    EasyTcpClient(){
        _cfd = INVALID_SOCKET;
    };
    virtual ~EasyTcpClient(){
        Close();
    };
//初始化socket
    int initSocket(){

#ifdef _WIN32
        WORD ver = MAKEWORD(2,2);
        WSADATA dat;
        WSAStartup(ver, &dat);
#endif
        if(_cfd!=INVALID_SOCKET)
        {
            printf("关闭旧连接：%d.\n", _cfd);
            Close();
        }
        _cfd = socket(AF_INET, SOCK_STREAM, 0);
        if(_cfd == INVALID_SOCKET)
        {
            printf("SOCKET 建立失败.\n");
            return -1;
        }else{
            printf("SOCKET 建立成功.\n");
            return 0;
        }

    }
//连接服务器
    int Connect(char* ip, unsigned short port){
        if(_cfd == INVALID_SOCKET){
            initSocket();
        }
        struct sockaddr_in sev;
        sev.sin_family = AF_INET;
        sev.sin_port = htons(port);
#ifdef _WIN32
        sev.sin_addr.S_un.S_addr = inet_addr(ip);
#else 
        inet_pton(AF_INET, ip, &sev.sin_addr.s_addr);
#endif
        
        int ret = connect(_cfd, (struct sockaddr*)&sev, sizeof(sev));
        if(ret==-1)
        {
            printf("连接服务器失败.\n");
            return -1;
        }else{
            printf("连接服务器成功.\n");
            return 0;
        }
    }
//关闭服务器
    void Close(){
        if(_cfd!=INVALID_SOCKET){
#ifdef _WIN32
        closesocket(_cfd);
        WSACleanup();
#else
        close(_cfd);
#endif
        _cfd = INVALID_SOCKET;
        }
    }
//收数据
//发送数据
//处理数据
    bool isRun(){
        return _cfd!=INVALID_SOCKET;
    }
    bool OnRun(){
        if(isRun()){
            fd_set fr;
            FD_ZERO(&fr);
            FD_SET(_cfd, &fr);
            timeval t = {1,0};
            int ret = select(_cfd+1, &fr, nullptr, nullptr, &t);
            if(ret<0){
                printf("<socket=%d>Select 失败\n", _cfd);
                return false;
            }
            if(FD_ISSET(_cfd, &fr)){
                FD_CLR(_cfd, &fr);
                if(-1==RecData(_cfd))
                {
                    printf("%d与服务器断开连接.\n", _cfd);
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    //接收数据 处理粘包
    int RecData(int cfd){
        char buf[BUFSIZ];
        int len = recv(cfd, buf, sizeof(DataHeader), 0);
        DataHeader* header = (DataHeader*)buf;
        if(len<=0)
        {
            printf("与服务器断开连接.\n");
            return -1;
        }
        recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
        OnNetMsg(header);
        return 0;
    }   

    void OnNetMsg(DataHeader* header){
            switch (header->cmd)
            {
            case CMD_LOGIN_RESULT:
            {
                LoginResult* login;
                login = (LoginResult*)header;
                printf("LOGINRESULT, 返回结果为：%d, 数据长度为：%d\n", login->result, login->DataLength);
            }
            break;
            case CMD_LOGOUT_RESULT:
            {
                LogoutResult* logout;
                logout = (LogoutResult*)header;
                printf("LOGOUTRESULT, 返回结果为：%d, 数据长度为：%d\n", logout->result, logout->DataLength);
            }
            break;
            case CMD_NEWUSERJOIN:
            {
                NewUserJoin* newjoin;
                newjoin = (NewUserJoin*)header;
                printf("%d上线了\n", newjoin->fd);
            }
            break;
            default:
                DataHeader header = {0, CMD_ERROR};
                send(_cfd, &header, sizeof(DataHeader), 0);
            break;
            }	       
    }

    int sendData(DataHeader* header){
        if(OnRun() && header!=nullptr){
            return send(_cfd, header, header->DataLength, 0);
        }
        return SOCKET_ERROR;
    }
};





#endif