#include <cstdio>
#include <unistd.h>
#include <iostream>
#include <netinet/in.h>
#include <sys/socket.h>
#include <string.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <sys/time.h>

enum CMD{
	CMD_LOGIN,
	CMD_LOGIN_RESULT,
	CMD_LOGOUT,
	CMD_LOGOUT_RESULT,
	CMD_NEWUSERJOIN,
	CMD_ERROR
};
struct DataHeader{
	short DataLength;
	short cmd;
};

struct Login : public DataHeader
{
	Login()
	{
		DataLength = sizeof(Login);
		cmd = CMD_LOGIN;
	}
	char username[32];
	char password[32];
};

struct LoginResult : public DataHeader
{
	LoginResult(){
		DataLength = sizeof(LoginResult);
		cmd = CMD_LOGIN_RESULT;
		result = 0;
	}
	int result;
};
struct Logout : public DataHeader
{
	Logout(){
		DataLength = sizeof(Logout);
		cmd = CMD_LOGOUT;
	}
	char username[32];
};
struct LogoutResult : public DataHeader
{
	LogoutResult(){
		DataLength = sizeof(LogoutResult);
		cmd = CMD_LOGOUT_RESULT;
		result = 0;
	}
	int result;
};

struct NewUserJoin : public DataHeader
{
	NewUserJoin(){
		DataLength = sizeof(NewUserJoin);
		cmd = CMD_NEWUSERJOIN;
		int fd =0;
	}
	int fd;
};




struct Data{
	int age;
	char name[32];
};

int process(int cfd){
	char buf[BUFSIZ];
	int len = recv(cfd, buf, sizeof(DataHeader), 0);
	DataHeader* header = (DataHeader*)buf;
	if(len<=0)
	{
		printf("客户端 %d 已经下线.\n",cfd);
		return -1;
	}
	printf("收到 %d 的命令%d, 数据长度%d\n", cfd, header->cmd, header->DataLength);
	switch (header->cmd)
	{
	case CMD_LOGIN:
		{
		Login* login;
		recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
		login = (Login*)buf;
		printf("登录账户：%s, password = %s\n", login->username, login->password);
		//判断账户名密码
		LoginResult ret;
		send(cfd, &ret, sizeof(LoginResult), 0);
	}
		break;
	case CMD_LOGOUT:
	{
		Logout* logout;
		recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
		logout = (Logout*)buf;
		printf("下线名：%s\n", logout->username);
		LogoutResult ret;
		send(cfd, &ret, sizeof(LogoutResult), 0);
	}
	break;
	default:
		DataHeader header = {0, CMD_ERROR};
		send(cfd, &header, sizeof(DataHeader), 0);
	break;
	}	
}

#define SEV_IP "127.0.0.1"
#define SEV_PORT 6668
int main(){
	int lfd = socket(AF_INET, SOCK_STREAM, 0);
	if(lfd==-1)
		perror("Socket 创建失败");
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(SEV_PORT);
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	int ret = bind(lfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
	if(ret == -1)
	{
		perror("bind");
		exit(-1);
	}
	ret = listen(lfd, 5);
	if(ret==-1)
	{
		perror("listen:");
		exit(-1);
	}
	printf("绑定端口:%d成功，正自监听.....\n",ntohs(serv_addr.sin_port));
	fd_set fd_r, r_set;
	FD_ZERO(&fd_r);
	FD_SET(lfd, &fd_r);
	int maxfd = lfd;
	int numofClient = 0;
	
	while(1){
		//添加select
		r_set = fd_r;
		timeval t = {1,0};
		int ret = select(maxfd+1, &r_set, nullptr, nullptr, &t);
		if(ret<0)
		{
			printf("select 任务结束。\n");
			break;
		}
		if(FD_ISSET(lfd, &r_set)){
			int cfd;
			struct sockaddr_in client_addr = {};
			socklen_t len = sizeof(client_addr);
			cfd = accept(lfd, (struct sockaddr*)&client_addr, &len);
			if(cfd == -1){
				perror("accept:");
				continue;
			}
			for(int i=lfd+1;i<=maxfd;i++){
				if(FD_ISSET(i, &fd_r)){
					NewUserJoin userjoin;
					userjoin.fd = cfd;
					send(i, &userjoin, sizeof(NewUserJoin), 0);
					printf("发送到:%d\n", i);
				}
			}
			FD_SET(cfd, &fd_r);
			numofClient++;
			if(cfd>maxfd)
				maxfd = cfd;
			printf("client ip:%s, client port:%d已经上线\n", 
					inet_ntoa(client_addr.sin_addr),
					ntohs(client_addr.sin_port));
		}
		for(int i=lfd+1;i<=maxfd;i++){
			if(FD_ISSET(i, &r_set)){
				if(-1 == process(i)){
					FD_CLR(i, &fd_r);
					numofClient--;
					close(i);
				}
			}
		}
		printf("正在监视%d个客户端，do something else...\n",numofClient);
	}
	close(lfd);
	return 0;
}
