#ifndef _MessageHeader_HPP_
#define _MessageHeader_HPP_
enum CMD{
	CMD_LOGIN,
	CMD_LOGIN_RESULT,
	CMD_LOGOUT,
	CMD_LOGOUT_RESULT,
	CMD_NEWUSERJOIN,
	CMD_ERROR
};
struct DataHeader{
	short DataLength;
	short cmd;
};

struct Login : public DataHeader
{
	Login()
	{
		DataLength = sizeof(Login);
		cmd = CMD_LOGIN;
	}
	char username[32];
	char password[32];
};

struct LoginResult : public DataHeader
{
	LoginResult(){
		DataLength = sizeof(LoginResult);
		cmd = CMD_LOGIN_RESULT;
		result = 0;
	}
	int result;
};
struct Logout : public DataHeader
{
	Logout(){
		DataLength = sizeof(Logout);
		cmd = CMD_LOGOUT;
	}
	char username[32];
};
struct LogoutResult : public DataHeader
{
	LogoutResult(){
		DataLength = sizeof(LogoutResult);
		cmd = CMD_LOGOUT_RESULT;
		result = 0;
	}
	int result;
};
struct NewUserJoin : public DataHeader
{
	NewUserJoin(){
		DataLength = sizeof(NewUserJoin);
		cmd = CMD_NEWUSERJOIN;
		int fd =0;
	}
	int fd;
};

#endif