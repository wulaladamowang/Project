#include <cstdio>
#include <iostream>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>

enum CMD{
	CMD_LOGIN,
	CMD_LOGIN_RESULT,
	CMD_LOGOUT,
	CMD_LOGOUT_RESULT,
	CMD_NEWUSERJOIN,
	CMD_ERROR
};
struct DataHeader{
	short DataLength;
	short cmd;
};

struct Login : public DataHeader
{
	Login()
	{
		DataLength = sizeof(Login);
		cmd = CMD_LOGIN;
	}
	char username[32];
	char password[32];
};

struct LoginResult : public DataHeader
{
	LoginResult(){
		DataLength = sizeof(LoginResult);
		cmd = CMD_LOGIN_RESULT;
		result = 0;
	}
	int result;
};
struct Logout : public DataHeader
{
	Logout(){
		DataLength = sizeof(Logout);
		cmd = CMD_LOGOUT;
	}
	char username[32];
};
struct LogoutResult : public DataHeader
{
	LogoutResult(){
		DataLength = sizeof(LogoutResult);
		cmd = CMD_LOGOUT_RESULT;
		result = 0;
	}
	int result;
};
struct NewUserJoin : public DataHeader
{
	NewUserJoin(){
		DataLength = sizeof(NewUserJoin);
		cmd = CMD_NEWUSERJOIN;
		int fd =0;
	}
	int fd;
};

struct Data{
	int age;
	char name[32];
};


int process(int cfd){
	char buf[BUFSIZ];
	int len = recv(cfd, buf, sizeof(DataHeader), 0);
	DataHeader* header = (DataHeader*)buf;
	if(len<=0)
	{
		printf("与服务器断开连接.\n");
		return -1;
	}
	printf("收到的命令%d, 数据长度%d\n", header->cmd, header->DataLength);
	switch (header->cmd)
	{
	case CMD_LOGIN_RESULT:
	{
		LoginResult* login;
		recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
		login = (LoginResult*)buf;
		printf("LOGINRESULT, 返回结果为：%d, 数据长度为：%d\n", login->result, login->DataLength);
	}
	break;
	case CMD_LOGOUT_RESULT:
	{
		LogoutResult* logout;
		recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
		logout = (LogoutResult*)buf;
		printf("LOGOUTRESULT, 返回结果为：%d, 数据长度为：%d\n", logout->result, logout->DataLength);
	}
	break;
	case CMD_NEWUSERJOIN:
	{
		NewUserJoin* newjoin;
		recv(cfd, buf+sizeof(DataHeader), header->DataLength-sizeof(DataHeader), 0);
		newjoin = (NewUserJoin*)buf;
		printf("%d上线了\n", newjoin->fd);
	}
	break;
	default:
		DataHeader header = {0, CMD_ERROR};
		send(cfd, &header, sizeof(DataHeader), 0);
	break;
	}	
}


#define SEV_PORT 6666
#define SEV_IP "127.0.0.1"
int main(){
	int cfd = socket(AF_INET, SOCK_STREAM, 0);
	if(cfd == -1)
	{
		perror("socket:");
		exit(-1);
	}
	struct sockaddr_in sev;
	sev.sin_family = AF_INET;
	sev.sin_port = htons(SEV_PORT);
	inet_pton(AF_INET, SEV_IP, &sev.sin_addr.s_addr);
	
	int ret = connect(cfd, (struct sockaddr*)&sev, sizeof(sev));
	if(ret==-1)
	{
		perror("connect");
		exit(-1);
	}
	char buff[BUFSIZ];
	while(1){
		fd_set fr;
		FD_ZERO(&fr);
		FD_SET(cfd, &fr);
		timeval t = {1,0};
		int ret = select(cfd+1, &fr, nullptr, nullptr, &t);
		if(ret<0){
			printf("Select 失败\n");
			break;
		}
		if(FD_ISSET(cfd, &fr)){
			FD_CLR(cfd, &fr);
			if(-1==process(cfd))
			{
				printf("与服务器断开连接.\n");
				break;
			}
		}
		printf("do somthing else\n");
		Login login;
		strcpy(login.username, "wu");
		strcpy(login.password, "wuwuwu");
		send(cfd, &login, sizeof(Login), 0);
		sleep(1);
		// scanf("%s",buff);
		// if(0==strcmp(buff, "exit"))
		// {
		// 	printf("exit指令，客户端关闭连接\n");
		// 	break;
		// }else if(0==strcmp(buff, "login")){
		// 	Login login;
		// 	strcpy(login.username, "wu");
		// 	strcpy(login.password, "970221");
		// 	send(cfd, &login, sizeof(login), 0);
			
		// 	//接受数据
		// 	LoginResult ret = {};
		// 	recv(cfd, &ret, sizeof(ret), 0);
		// 	printf("Login返回的结果为：%d\n", ret.result);
		// }else if(0==strcmp(buff, "logout")){
		// 	Logout logout;
		// 	strcpy(logout.username, "wu");
		// 	send(cfd, &logout, sizeof(Logout), 0);

		// 	LogoutResult lh = {};
		// 	recv(cfd, &lh, sizeof(LogoutResult), 0);
		// 	printf("Logout返回结果为：%d\n", lh.result);
		// }else{
		// 	printf("输出指令有误，请重新输入。\n");
		// }
	}
	close(cfd);
	printf("exit\n");
	return 0;
}
